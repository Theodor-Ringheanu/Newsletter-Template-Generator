﻿using System.Windows;


namespace Newsletter_Template_Generator
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
        }
    }
}
